<?php
class User {
    private $db;

    public function __construct($db) {
        $this->db = $db;
    }

    public function register($data) {
        $stmt = $this->db->prepare("INSERT INTO users (username, email, password, confirmation_token) VALUES (?, ?, ?, ?)");
        return $stmt->execute([$data['username'], $data['email'], $data['password'], $data['confirmation_token']]);
    }

    public function findByEmail($email) {
        $stmt = $this->db->prepare("SELECT * FROM users WHERE email = ?");
        $stmt->execute([$email]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    public function findByToken($token) {
        $stmt = $this->db->prepare("SELECT * FROM users WHERE confirmation_token = ?");
        $stmt->execute([$token]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    public function confirmAccount($id) {
        $stmt = $this->db->prepare("UPDATE users SET confirmed = 1, confirmation_token = NULL WHERE id = ?");
        return $stmt->execute([$id]);
    }

    public function update($id, $data) {
        $stmt = $this->db->prepare("UPDATE users SET username = ?, email = ?, password = ? WHERE id = ?");
        return $stmt->execute([$data['username'], $data['email'], $data['password'], $id]);
    }

    public function updateAvatar($id, $avatarPath) {
        $stmt = $this->db->prepare("UPDATE users SET avatar = ? WHERE id = ?");
        return $stmt->execute([$avatarPath, $id]);
    }
}
?>
