<?php
require_once 'db.php';
require_once 'models/User.php';
require_once 'controllers/AuthController.php';
require_once 'controllers/ProfileController.php';
require_once 'controllers/AvatarController.php';


$db = new PDO('mysql:host=localhost;dbname=Authentification', 'root', '');
$db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

$userModel = new User($db);

$authController = new AuthController($userModel);
$profileController = new ProfileController($userModel);
$avatarController = new AvatarController($userModel);

$action = $_GET['action'] ?? '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if ($action === 'register') {
        $authController->register($_POST);
    } elseif ($action === 'login') {
        $authController->login($_POST);
    } elseif ($action === 'updateProfile') {
        $profileController->update($_POST);
    } elseif ($action === 'uploadAvatar') {
        $avatarController->upload($_FILES['avatar']);
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    if ($action === 'confirm' && isset($_GET['token'])) {
        $authController->confirm($_GET['token']);
    }
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <link rel="stylesheet" href="style.css">
</head>
<div class="navbar">
    <a href="?action=registerView">Créer un compte</a>
    <a href="?action=loginView">Connexion</a>
    <a href="?action=profileView">Mon profil</a>
</div>

<head>
    <meta charset="UTF-8">
    <title>Système d'authentification</title>
</head>
<body>
    <nav>
        <a href="?action=registerView">Créer un compte</a>
        <a href="?action=loginView">Connexion</a>
        <a href="?action=profileView">Mon profil</a>
    </nav>
    <?php
    if ($action === 'registerView') {
        include 'views/inscription.php';
    } elseif ($action === 'loginView') {
        include 'views/connexion.php';
    } elseif ($action === 'profileView') {
        include 'views/profil.php';
    }
    ?>
 

</body>
</html>
