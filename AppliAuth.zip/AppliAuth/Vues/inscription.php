<div class="container">
    <h2>Créer un compte</h2>
    <form method="POST" action="?action=register">
        <label for="username">Nom d'utilisateur</label>
        <input type="text" id="username" name="username" placeholder="Entrez votre nom d'utilisateur" required>

        <label for="email">Email</label>
        <input type="email" id="email" name="email" placeholder="Entrez votre email" required>

        <label for="password">Mot de passe</label>
        <input type="password" id="password" name="password" placeholder="Entrez un mot de passe" required>

        <button type="submit">S'inscrire</button>
    </form>
</div>
