<div class="container">
    <h2>Modifier mon profil</h2>
    <form method="POST" action="?action=updateProfile">
        <label for="username">Nouveau nom d'utilisateur</label>
        <input type="text" id="username" name="username" placeholder="Entrez un nouveau nom d'utilisateur">

        <label for="email">Nouvel email</label>
        <input type="email" id="email" name="email" placeholder="Entrez un nouvel email">

        <label for="password">Nouveau mot de passe</label>
        <input type="password" id="password" name="password" placeholder="Entrez un nouveau mot de passe">

        <button type="submit">Mettre à jour</button>
    </form>

    <h2 class="mt-4">Mettre à jour mon avatar</h2>
    <form method="POST" enctype="multipart/form-data" action="?action=uploadAvatar">
        <label for="avatar">Choisir un avatar</label>
        <input type="file" id="avatar" name="avatar" required>

        <button type="submit">Mettre à jour l'avatar</button>
    </form>
</div>
