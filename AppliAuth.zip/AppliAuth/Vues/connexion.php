<div class="container">
    <h2>Se connecter</h2>
    <form method="POST" action="?action=login">
        <label for="email">Email</label>
        <input type="email" id="email" name="email" placeholder="Entrez votre email" required>

        <label for="password">Mot de passe</label>
        <input type="password" id="password" name="password" placeholder="Entrez votre mot de passe" required>

        <button type="submit">Se connecter</button>
    </form>
</div>
