<?php
class AuthController {
    private $user;

    public function __construct($user) {
        $this->user = $user;
    }

    public function register($data) {
        $data['password'] = password_hash($data['password'], PASSWORD_BCRYPT);
        $data['confirmation_token'] = bin2hex(random_bytes(16));

        if ($this->user->register($data)) {
            $confirmationLink = "http://localhost/index.php?action=confirm&token=" . $data['confirmation_token'];
            echo "Inscription réussie ! Lien de confirmation : <a href=\"$confirmationLink\">$confirmationLink</a>";
        } else {
            echo "Erreur lors de l'inscription.";
        }
    }

    public function login($data) {
        $user = $this->user->findByEmail($data['email']);
        if ($user && password_verify($data['password'], $user['password'])) {
            session_start();
            $_SESSION['user_id'] = $user['id'];
            echo "Connexion réussie !";
        } else {
            echo "Email ou mot de passe incorrect.";
        }
    }

    public function confirm($token) {
        $user = $this->user->findByToken($token);
        if ($user) {
            $this->user->confirmAccount($user['id']);
            echo "Compte confirmé avec succès !";
        } else {
            echo "Jeton de confirmation invalide.";
        }
    }
}
?>
