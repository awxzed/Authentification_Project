<?php
class ProfileController {
    private $user;

    public function __construct($user) {
        $this->user = $user;
    }

    public function update($data) {
        session_start();
        if (!isset($_SESSION['user_id'])) {
            echo "Vous devez être connecté.";
            return;
        }

        $this->user->update($_SESSION['user_id'], $data);
        echo "Profil mis à jour avec succès.";
    }
}
?>
