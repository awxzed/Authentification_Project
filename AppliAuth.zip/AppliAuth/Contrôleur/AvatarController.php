<?php
class AvatarController {
    private $user;

    public function __construct($user) {
        $this->user = $user;
    }

    public function upload($file) {
        session_start();
        if (!isset($_SESSION['user_id'])) {
            echo "Vous devez être connecté.";
            return;
        }

        $targetDir = "uploads/avatars/";
        $targetFile = $targetDir . basename($file['name']);
        if (move_uploaded_file($file['tmp_name'], $targetFile)) {
            $this->user->updateAvatar($_SESSION['user_id'], $targetFile);
            echo "Avatar mis à jour avec succès.";
        } else {
            echo "Erreur lors de l'upload.";
        }
    }
}
?>
