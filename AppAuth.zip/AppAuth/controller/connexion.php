<?php

include 'modèle/user.php'; 
$email = htmlspecialchars($_POST['email']); 
$password = htmlspecialchars($_POST['password']); 

$bdd = dbConnect(); 

if (connect($bdd, $email, $password) != false) 
{
    header('index.html²²'); 
}
else {
    echo 'erreur, mot de passe ou email incorrect(s)'; 
    
}