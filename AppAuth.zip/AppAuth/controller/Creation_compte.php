<?php

include ('modèle/user.php'); 
session_start();

if (isset($_SESSION['LOGGED_USER']) && isset($_POST['profile'])) {
    
    if (
        isset($_POST['email'], $_POST['username'], $_POST['password']) &&
        !empty($_POST['email']) &&
        !empty($_POST['username']) &&
        !empty($_POST['password'])
    ) {
        $email = $_POST['email'];
        $username = $_POST['username'];
        $password = $_POST['password'];

        // Regex 
        $emailRegex = "/^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,6}$/";
        $usernameRegex = "/^[a-zA-Z0-9_-]{3,16}$/";
        $passwordRegex = "/^(?=.*[A-Z])(?=.*[a-z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/";

        // Validation des champs
        if (!preg_match($emailRegex, $email)) {
            echo "Adresse email invalide.";
        } elseif (!preg_match($usernameRegex, $username)) {
            echo "Nom d'utilisateur invalide.";
        } elseif (!preg_match($passwordRegex, $password)) {
            echo "Mot de passe invalide.";
        } else {
            
            echo "Toutes les données sont valides.";
           
        }
    } else {
        echo "Tous les champs (email, nom d'utilisateur, mot de passe) sont obligatoires.";
    }
} else {
    echo "Accès non autorisé.";
}
