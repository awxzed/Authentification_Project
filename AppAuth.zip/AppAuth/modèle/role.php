<?php
// Connexion à la BDD :
function dbConnect()
{
    try {
        $bdd = new PDO('mysql:host=localhost;dbname=authentification;charset=utf8', 'root', ''); 
        $bdd->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        return $bdd; 
    } catch (PDOException $e) {
        die('Erreur : ' . $e->getMessage());
    }
}

//  récup tous les roles depuis la table 
function getRoles($bdd)
{
    $query = "SELECT id, name FROM roles"; 
    $result = $bdd->query($query); 
    return $result->fetchAll(PDO::FETCH_ASSOC); 
}


function connect($bdd, $email, $pwd) : bool 
{
    
    $query = "SELECT u.id, u.username, u.password, u.confirmed, r.name AS role_name 
              FROM users u
              LEFT JOIN user_roles ur ON u.id = ur.user_id
              LEFT JOIN role r ON ur.role_id = r.id
              WHERE u.email = :email"; 
    $resultat = $bdd->prepare($query); 
    $resultat->execute(['email' => $email]); 

    $user = $resultat->fetch(PDO::FETCH_ASSOC); 

    
    if ($user && password_verify($pwd, $user['password'])) {
        
        if ($user['confirmed']) {
            $_SESSION['LOGGED_USER'] = $user['username']; 
            $_SESSION['USER_ROLE'] = $user['role_name'];  
            return true; 
        } else {
            
            return false; 
        }
    } else {
        
        return false; 
    }
}
?>