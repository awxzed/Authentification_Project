<?php

// Connexion à la BDD : 
function dbConnect()
{
    try {
        $bdd = new PDO('mysql:host=localhost;dbname=authentification;charset=utf8', 'root', ''); 
        $bdd->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        return $bdd; 
    } catch (PDOException $e) {
        die('Erreur : ' . $e->getMessage());
    }
}




function connect($bdd, $email, $password) : bool 
{
    
    $query = "SELECT id, username, password, confirmed FROM users WHERE email = :email"; 
    $resultat = $bdd->prepare($query); 
    $resultat->execute(['email' => $email]); 

    $user = $resultat->fetch(PDO::FETCH_ASSOC); // Récupérer les résultats

    // Vérifier si l'utilisateur existe et si le mot de passe correspond
    if ($user && password_verify($password, $user['password'])) {
        // Vérifier si le compte est confirmé
        if ($user['confirmed']) {
            $_SESSION['LOGGED_USER'] = $user['username']; 
            return true; 
        } else {
            
            return false; 
        }
    } else {
        // Mauvais email
        return false; 
    }
}

?>
